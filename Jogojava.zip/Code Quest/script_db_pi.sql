create database db_pi;
use db_pi;

create table tb_perguntas(num_pergunta integer auto_increment primary key,
	pergunta varchar(200) not null,
    alternativa_a varchar(200) not null,
    alternativa_b varchar(200) not null,
    alternativa_c varchar(200) not null,
    alternativa_d varchar(200) not null,
    resposta char(1) not null,
    dificuldade varchar(20)
);

create table tb_jogadores(id integer auto_increment primary key,
	nome varchar(200) not null unique,
    senha varchar(200) not null,
    pontos integer
);

insert into tb_jogadores(nome,senha) values ('adm', 'adm');

select * from tb_jogadores;

select * from tb_perguntas;
